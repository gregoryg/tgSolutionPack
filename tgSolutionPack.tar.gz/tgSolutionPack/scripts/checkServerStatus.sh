#!/bin/bash

###############################################
# Copyright (c)  2015-now, TigerGraph Inc.
# All rights reserved
# Solution pack for TigerGraph Pre Sales
# Author: robert.hardaway@tigergraph.com
################################################

echo 'Ensure mysql is installed and running on the host'
echo ''
echo 'This script assume a local user can login to the mysql database.'
echo ' Run this command to ensure the user can login by providing a pw'
echo ''
echo '   mysql -ubob -p'
echo ''
echo ' for user bob, and supplying their password, login is successful.'
echo ''

myResult=$(mysql -V)
if [[ "$myResult" == "" ]]; then
	echo 'mysql doesnt appear to be installed, please address'
	exit 2
else
	exit 0
fi

FILE=/usr/local/mysql/bin/mysql
if [[ -f "$FILE" ]]; then
    echo "mysql is installed."
else
	echo 'if running on a Mac, mysql doesnt appear to be installed, please address'
	exit 2
fi

exit 0


