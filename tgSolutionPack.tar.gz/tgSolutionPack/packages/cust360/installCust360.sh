gsql ./cust360/scripts/create_cust360_schema.gsql
gsql ./cust360/scripts/customer360_load_er.gsql
gsql ./cust360/scripts/customer360_load_camp.gsql
gsql ./cust360/scripts/customer360_load_events.gsql
gsql ./cust360/scripts/customer360_load_orders.gsql
gsql ./cust360/scripts/customer360_load_ratings.gsql
