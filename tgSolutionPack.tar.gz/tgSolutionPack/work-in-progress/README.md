# Demo packages under development

Please refer to the principles for contributors.

Each package should go under its own directory, named uniquely so as not to conflict with an existing package in the `packages` directory.

Once your package is working in a clustered TigerGraph environment, move it to the `packages` directory and create a pull request
